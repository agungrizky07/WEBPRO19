function validasi(){
    var nama = document.getElementById("nama").value;
    var email = document.getElementById("email").value;
    var alamat = document.getElementById("alamat").value;

    if((nama != "") && (email != "") && (alamat != "")){
    	alert("Halo "+nama+" selamat datang");
   	} else{
   		alert("Anda harus mengisi data dengan lengkap!");
   	}
 }
function ubahBackground(){
	document.body.style.background = "url('image.jpg') no-repeat";
}
function ubahFont(){
	document.getElementById("telkom").style.fontFamily = "Algerian";
}
function ubahUkuranF(){
	document.getElementById("telkom").style.fontSize = "50px";
}
function ubahWarnaF(){
	document.getElementById("telkom").style.color = "pink";
}
function hapus(){
	document.getElementById("telkom").remove();
}